Shell permissions projects
