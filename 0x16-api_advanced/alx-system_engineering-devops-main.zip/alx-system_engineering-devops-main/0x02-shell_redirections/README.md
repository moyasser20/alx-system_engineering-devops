# Shell I/O Redirection and Filters
0. Hello World - Print new line at end of standard output
1. Confused smiley - Script that displays a confused smiley
2. Display the content of the /etc/passwd file
3. Script to display two files
4. Display last 10 lines
5. Display first 10 lines
6. Display nth line
7. Ignore special characters
8. Redirect input to other file
9. Duplicate nth line and redirect output
10. Remove javascript files
11. Find and count directories
12. Display 10 newest files
13. Sort and display unique lines
14. Find specific word in a file
15. Find the count of lines with that match your search pattern
16. Display next n lines after search
17. Display lines that don't meet search pattern
18. Display lines starting with a letter
19. Replace characters
20. Delete specified characters
21. Display output in reverse
22. Sort then select fields to display
