# Shell, init files, variables and expansions
0. Script for alias rm*
