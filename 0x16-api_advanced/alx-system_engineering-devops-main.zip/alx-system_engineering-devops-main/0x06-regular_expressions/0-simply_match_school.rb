#!/usr/bin/env ruby
# Regular expression to match 'School'

puts ARGV[0].scan(/School\b/).join
