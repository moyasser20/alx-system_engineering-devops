#!/usr/bin/env ruby
# Regular expression to match one or more of incidence of 't'

puts ARGV[0].scan(/hbt+n$/).join
