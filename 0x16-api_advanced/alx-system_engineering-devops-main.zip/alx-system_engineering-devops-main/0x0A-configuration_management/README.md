# 0x0A. Configuration management

## About
Configuration managment using Puppet

## Tasks
0. Manifest to create a file in `/tmp`
	* [0-create_a_file.pp](0-create_a_file.pp)
1. Manifest to install `flask` version `2.1.0`
	* [1-install_a_package.pp](1-install_a_package.pp)
2. Manifest to execute `pkill` on `killmenow` program
	* [2-execute_a_command.pp](2-execute_a_command.pp)
