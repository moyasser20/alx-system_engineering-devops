# 0x0B. SSH

## About
Secure Shell Encryption and Connection

## Tasks
0. Script that uses ssh to cnnect to your server using private key`~/.ssh/school` with the user `ubuntu`
	* [0-use_a_private_key](0-use_a_private_key)
1. Script to generate RSA key pair
	* [1-create_ssh_key_pair](1-create_ssh_key_pair)
2. SHH client configuration for password-less login
	* [2-ssh_config](2-ssh_config)
3. Puppet manifest to change cofiguration file
	* [100-puppet_ssh_config.pp](100-puppet_ssh_config.pp)
