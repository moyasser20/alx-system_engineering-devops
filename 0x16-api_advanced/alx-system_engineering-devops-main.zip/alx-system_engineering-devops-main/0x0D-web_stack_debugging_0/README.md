# 0x0D. Web stack debugging #0

## About
Web stack debugging - Apache Server

## Tasks
0. Shel script to fix Apache server not responding to requests
	* [0-give_me_a_page](0-give_me_a_page)
