# 0x0E. Web stack debugging #1

## About
Web stack debugging - Nginx server

## Tasks
0. Bash script to fix nginx configuration
	* [0-nginx_likes_port_80](0-nginx_likes_port_80)
1. Bash script to fix nginx configuration
	* [1-debugging_made_short](1-debugging_made_short)
