## 0x11. What happens when you type google.com in your browser and press Enter

## About
What happens when you type google.com on your browser
## Tasks
0. Blog post to answer the question **'What happens when you type google.com on your browser and press enter?'**
* [0-blog_post](0-blog_post)
1. Shema to follow the request for **google.com**
* [1-what_happen_when_diagram](1-what_happen_when_diagram)
2. Contribution to the [what-happens-when](https://github.com/alex/what-happens-when) repository
* [2-contribution-to_what-happens-when_github_answer](2-contribution-to_what-happens-when_github_answer)
