# 0x17. Web stack debugging #3

## About
Find and fixing errors in web stack
* Tools: `strace` and `puppet`

## Tasks
0. Find source of sever error and write a puppet manifest to fix the error
	* [0-strace_is_your_friend.pp](0-strace_is_your_friend.pp)
