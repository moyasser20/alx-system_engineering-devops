# 0x18. Webstack monitoring

## About
Server monitoring
* Datadog

## Tasks
0. Installing datadog
1. Monitoring metrics
2. Setting up datadog dashboards
