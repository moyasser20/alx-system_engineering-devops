# 0x19. Postmortem

## About
Writing incident reports

## Tasks
0. Write a postmortem for a fictional incident
1. Enrich the postmortem from task 0 using humor, images, etc.
