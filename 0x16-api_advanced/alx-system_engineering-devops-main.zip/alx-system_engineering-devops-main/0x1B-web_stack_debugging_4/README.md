# 0x1B. Web stack debugging #4

## About
More debugging :bug:

## Tasks
0. Fixing `NGINX` file limits
	* [0-the_sky_is_the_limit_not.pp](0-the_sky_is_the_limit_not.pp)
1. Fixing user file limits
	* [1-user_limit.pp](1-user_limit.pp)
