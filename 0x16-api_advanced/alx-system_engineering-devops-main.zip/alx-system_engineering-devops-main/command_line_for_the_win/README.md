# Command line for the win

## About
[Command line challenge](https://cmdchallenge.com/)

## Tasks :page_with_curl:
0. Task 0 - 9 of CMD challenge
	* [0-first_9_tasks.png](0-first_9_tasks.png)
1. Task 10 - 18 of CMD challenge
	* [1-next_9_tasks.png](1-next_9_tasks.png)
2. Task 19 - 42 of CMD challenge
	* [2-next_9_tasks.png](2-next_9_tasks.png)
